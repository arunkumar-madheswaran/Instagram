import React, {Component} from 'react';
import $ from 'jquery';


class Insta extends Component {

	constructor(props) {
	  super(props);		
      this.state = {
         data: ''
      }
   }

	handleClick() {		
		let insta_id = this.refs.myinput.value;
		 $.ajax({
            url: "https://api.instagram.com/v1/users/{insta_id}/media/recent/?access_token=642176ece1e7445e99244cec26f4de1f",
            method: 'POST',
            success: function(response){
                this.setState({data:response})
            },
            error: function(){
                console.log("Couldn't connect to Instagram");
            }
        });
	}

    render() {
        return (
            <div>
               Instagram Id : <input type="text" ref="myinput" id="instag_id" />
			   <button onClick={this.handleClick.bind(this)}>Submit</button>
			   <table>
				<tr>
					<th>Picture</th><th>Hash Tag</th>
				</tr>
				<tr>
					<td>{this.state.data.picture}</td>
					<td>{this.state.data.hash_tag}</td>
				</tr>
            </div>
        );
    }
}

export default Insta;