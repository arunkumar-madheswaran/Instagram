import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';
import Insta from './components/Insta';

import { Router, Route , browserHistory , hashHistory} from 'react-router';

ReactDOM.render(
    <Router history={browserHistory}>
        <Route path="/" component={App} >
			<Route path="/insta" component={Insta} />
        </Route>    
    </Router>    
    , document.getElementById('root'));